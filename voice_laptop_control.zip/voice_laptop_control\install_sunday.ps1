$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

Write-Host 'Sunday voice assistant setup' -ForegroundColor Cyan
Write-Host 'Project folder: ' $root

$pythonCommand = Get-Command py.exe -ErrorAction SilentlyContinue
if ($null -eq $pythonCommand) {
    $pythonCommand = Get-Command python.exe -ErrorAction SilentlyContinue
}

if ($null -eq $pythonCommand) {
    Write-Host ''
    Write-Host 'Python was not found.' -ForegroundColor Red
    Write-Host 'Install Python 3.11 or newer from https://www.python.org/downloads/'
    Write-Host 'During installation, enable: Add Python to PATH'
    exit 1
}

$python = $pythonCommand.Source
Write-Host ('Using Python: ' + $python) -ForegroundColor Green

$venvPython = Join-Path $root '.venv\Scripts\python.exe'
if (-not (Test-Path $venvPython)) {
    Write-Host 'Creating a private Python environment...'
    & $python -m venv (Join-Path $root '.venv')
    if ($LASTEXITCODE -ne 0) { throw 'Could not create the Python environment.' }
} else {
    Write-Host 'Existing private Python environment found.' -ForegroundColor Green
}

Write-Host 'Upgrading pip...'
& $venvPython -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'Could not upgrade pip.' }

Write-Host 'Installing required libraries: vosk, sounddevice, pyautogui...'
& $venvPython -m pip install -r (Join-Path $root 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Could not install the required libraries.' }

$modelPath = Join-Path $root 'model\vosk-model-small-en-us-0.15'
if (-not (Test-Path $modelPath)) {
    Write-Host 'Downloading the offline English speech model...'
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'download_model.ps1')
    if ($LASTEXITCODE -ne 0) { throw 'Could not download the speech model.' }
} else {
    Write-Host 'Speech model already exists; skipping download.' -ForegroundColor Green
}

Write-Host ''
Write-Host 'Setup completed successfully.' -ForegroundColor Green
Write-Host 'Start Sunday by running: Start-VoiceAssistant.bat'
Write-Host 'Or test it now with: .\.venv\Scripts\python.exe voice_assistant.py'
