import json
import queue
import re
import sys
import time
import urllib.parse
import webbrowser
from pathlib import Path

import pyautogui
import sounddevice as sd
from vosk import KaldiRecognizer, Model

try:
    import winsound
except ImportError:
    winsound = None

SAMPLE_RATE = 16000
WAKE_WORD = "sunday"
COMMAND_WINDOW_SECONDS = 6
MODEL_PATH = Path(__file__).parent / "model" / "vosk-model-small-en-us-0.15"

AUDIO_QUEUE = queue.Queue()
RUNNING = True
AWAITING_COMMAND = False
AWAITING_UNTIL = 0.0


def beep(frequency=880, duration=100):
    """Give simple local feedback without sending audio to a cloud service."""
    if winsound:
        winsound.Beep(frequency, duration)


def audio_callback(indata, frames, time_info, status):
    if status:
        print(f"Audio status: {status}", file=sys.stderr)
    AUDIO_QUEUE.put(bytes(indata))


def clean_text(text):
    return re.sub(r"\s+", " ", text.lower().strip())


def open_google():
    webbrowser.open("https://www.google.com")


def open_youtube():
    webbrowser.open("https://www.youtube.com")


def google_search(query):
    url = "https://www.google.com/search?q=" + urllib.parse.quote_plus(query)
    webbrowser.open(url)


def youtube_search(query):
    url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(query)
    webbrowser.open(url)


def run_command(command):
    """Run only explicitly approved actions. Returns False to stop the assistant."""
    global AWAITING_COMMAND, AWAITING_UNTIL
    command = clean_text(command)
    if not command:
        return True

    # Stop is intentionally explicit. This does not shut down Windows.
    if command in {"exit assistant", "quit assistant", "close assistant"}:
        print("Stopping voice assistant.")
        beep(500, 180)
        return False

    # Website allowlist. Do not replace this with arbitrary shell execution.
    if command in {"open google", "go to google"}:
        open_google()
        print("Opened Google.")
        return True

    if command in {"open youtube", "go to youtube"}:
        open_youtube()
        print("Opened YouTube.")
        return True

    match = re.fullmatch(r"search(?: for)? (.+)", command)
    if match:
        query = match.group(1).strip()
        if query:
            google_search(query)
            print(f"Searching Google for: {query}")
        return True

    match = re.fullmatch(r"(?:search youtube for|search youtube) (.+)", command)
    if match:
        query = match.group(1).strip()
        if query:
            youtube_search(query)
            print(f"Searching YouTube for: {query}")
        return True

    if command in {"scroll down", "scroll down a little"}:
        pyautogui.scroll(-5)
        print("Scrolled down.")
        return True

    if command in {"scroll up", "scroll up a little"}:
        pyautogui.scroll(5)
        print("Scrolled up.")
        return True

    if command in {"go back", "back"}:
        pyautogui.hotkey("alt", "left")
        print("Went back.")
        return True

    if command in {"go forward", "forward"}:
        pyautogui.hotkey("alt", "right")
        print("Went forward.")
        return True

    if command in {"open new tab", "new tab"}:
        pyautogui.hotkey("ctrl", "t")
        print("Opened a new tab.")
        return True

    if command in {"close tab", "close this tab"}:
        pyautogui.hotkey("ctrl", "w")
        print("Closed the current tab.")
        return True

    if command in {"refresh", "refresh page", "reload page"}:
        pyautogui.hotkey("ctrl", "r")
        print("Refreshed the page.")
        return True

    if command in {"switch tab", "next tab"}:
        pyautogui.hotkey("ctrl", "tab")
        print("Switched tab.")
        return True

    if command in {"stop loading", "stop"}:
        pyautogui.press("esc")
        print("Stopped loading.")
        return True

    print(f"Ignored unapproved command: {command!r}")
    return True


def extract_command(phrase):
    """Return (command, should_listen_for_next_phrase)."""
    global AWAITING_COMMAND, AWAITING_UNTIL
    phrase = clean_text(phrase)
    now = time.time()

    if AWAITING_COMMAND and now <= AWAITING_UNTIL:
        AWAITING_COMMAND = False
        return phrase, False

    AWAITING_COMMAND = False
    if phrase == WAKE_WORD:
        AWAITING_COMMAND = True
        AWAITING_UNTIL = now + COMMAND_WINDOW_SECONDS
        beep(1100, 80)
        print("Listening for a command...")
        return None, True

    prefix = WAKE_WORD + " "
    if phrase.startswith(prefix):
        return phrase[len(prefix):].strip(), False

    return None, False


def main():
    global RUNNING
    if not MODEL_PATH.exists():
        print(f"Model not found: {MODEL_PATH}")
        print("Run download_model.ps1 first, then start the assistant again.")
        sys.exit(1)

    print("Loading offline speech model...")
    model = Model(str(MODEL_PATH))
    recognizer = KaldiRecognizer(model, SAMPLE_RATE)
    recognizer.SetWords(False)

    print("Sunday is ready.")
    print("Say: 'Sunday, open Google' or say 'Sunday' and then a command.")
    print("Say: 'Sunday, exit assistant' to stop this program.")
    beep(880, 100)

    try:
        with sd.RawInputStream(
            samplerate=SAMPLE_RATE,
            blocksize=8000,
            dtype="int16",
            channels=1,
            callback=audio_callback,
        ):
            while RUNNING:
                data = AUDIO_QUEUE.get()
                if recognizer.AcceptWaveform(data):
                    result = json.loads(recognizer.Result())
                    phrase = result.get("text", "")
                    if not phrase:
                        continue
                    print(f"Heard: {phrase}")
                    command, waiting = extract_command(phrase)
                    if command:
                        RUNNING = run_command(command)
                        if RUNNING:
                            beep(880, 60)
    except KeyboardInterrupt:
        print("\nStopped by keyboard.")
    except Exception as exc:
        print(f"Assistant error: {exc}")
        print("Check that a microphone is connected and Windows microphone permission is enabled.")


if __name__ == "__main__":
    main()
