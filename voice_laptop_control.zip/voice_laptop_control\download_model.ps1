$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$modelDir = Join-Path $root 'model'
$zipPath = Join-Path $root 'vosk-model-small-en-us-0.15.zip'
$url = 'https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip'

New-Item -ItemType Directory -Force -Path $modelDir | Out-Null
Write-Host 'Downloading the official Vosk small English model (~40 MB)...'
Invoke-WebRequest -Uri $url -OutFile $zipPath
Write-Host 'Extracting model...'
Expand-Archive -Path $zipPath -DestinationPath $modelDir -Force
Remove-Item $zipPath -Force
Write-Host 'Model installed. You can now run Start-VoiceAssistant.bat.'
