@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_sunday.ps1"
if errorlevel 1 (
  echo.
  echo Setup failed. Read the message above, then try again.
  pause
  exit /b 1
)
echo.
echo Sunday is installed and ready.
pause
