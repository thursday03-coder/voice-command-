# Offline Windows Voice-Control Assistant

This starter project listens for the wake phrase **Sunday** and executes a small allowlist of browser commands locally. It does not send audio to a cloud speech service and it does not execute arbitrary shell commands.

## Commands included

- `Sunday open Google`
- `Sunday open YouTube`
- `Sunday search for weather in Delhi`
- `Sunday search YouTube for relaxing music`
- `Sunday scroll down`
- `Sunday scroll up`
- `Sunday go back`
- `Sunday go forward`
- `Sunday new tab`
- `Sunday close tab`
- `Sunday refresh`
- `Sunday switch tab`
- `Sunday stop loading`
- `Sunday exit assistant`

You can also say `Sunday`, wait for the beep, and then say the command within six seconds.

## Setup on Windows

1. Install Python 3.11 or newer from https://www.python.org/downloads/ and enable **Add Python to PATH** during installation.
2. Extract this project ZIP.
3. Double-click **Install-Sunday.bat**. It creates a private Python environment, installs every required library, and downloads the offline speech model.
4. When installation finishes, double-click **Start-VoiceAssistant.bat**.

If you prefer PowerShell, run `.\install_sunday.ps1` from this folder. The installer uses the following Python libraries:

- `vosk` — offline speech recognition
- `sounddevice` — microphone input
- `pyautogui` — scrolling and keyboard/browser controls

Allow microphone access if Windows asks. Keep the terminal open while testing.

## Start automatically after login

After the test works:

1. Press `Windows + R`.
2. Enter `shell:startup` and press Enter.
3. Create a shortcut in that folder pointing to `Start-VoiceAssistant.bat`.
4. Restart Windows or sign out and sign back in.

The assistant starts **after** Windows login; it does not bypass or automate your password. To stop it, say `Sunday exit assistant` or close its terminal window.

## Safety boundaries

Keep the allowlist small at first. Do not add arbitrary phrases such as “run this command” or “delete that file” until you have a confirmation step and a clear recovery plan. Voice recognition can mishear words, especially with noise or multiple speakers.

The assistant currently controls the active window for scrolling and browser shortcuts. Test it on a blank browser tab first.
